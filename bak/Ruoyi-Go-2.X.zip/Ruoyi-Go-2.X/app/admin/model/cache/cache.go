package cache

func InitCache() {
	//初始化字典
	InitDictCache()
	//初始化配置参数缓存
	InitSysConfigCache()
}
